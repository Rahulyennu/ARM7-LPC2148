#include<lpc214x.h>
void uart_init()
{
	U0LCR = 0X83;
	U0DLL = 97;
	U0DLM = 0;
	U0LCR = 0X03;
}
void uart_tx(unsigned char CH)
{
	U0THR = CH;
	while((U0LSR & (1<<6))==0);
}
unsigned char uart_rx()
{
	 while((U0LSR & (1<<0))==0);
	 return(U0RBR);
}

main()
{
	unsigned char X;
	PINSEL0 = 0X05;
	PINSEL2 = 0;
	IODIR1 &= ~(1<<16);
	IODIR1 |= (1<<17);
	uart_init();
	while(1)
	{
		X = uart_rx();
		if(X == 'A')
		{
			IOSET1 = (1<<17);
		}
		else if(X == 'B')
		{
			IOCLR1= (1<<17);
		}
	}
}
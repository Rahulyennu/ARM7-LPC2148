#include<lpc214x.h>
main()
{
	PINSEL2 = 0;
	IODIR1 &= ~(1<<16);
	IODIR1 |= (1<<17);
	while(1)
	{
		if((IOPIN1 & (1<<16))==0)
		{
			IOSET1 = (1<<17);
		}
		else
		{
			IOCLR1 = (1<<17);
		}
	}
}
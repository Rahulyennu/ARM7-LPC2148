#include<lpc214x.h>

void uart_init();
void uart_tx(unsigned char ch);
void uart_str(unsigned char *str);
unsigned char uart_rx();
main()
{
	unsigned char X;
	PINSEL0 = 0x00000005;
	PINSEL2 = 0;
	IODIR1 = (1<<16)|(1<<17);
	uart_init();
	uart_tx('a');
	uart_str("\nWAKE UP");
	while(1)
	{
		X = uart_rx();
		if(X == 'A')
		{
		  IOSET1 = (1<<16);
		  IOCLR1 = (1 << 17);
		}
		else if(X == 'B')
		{
		  
		  IOSET1 = (1<<17);
		  IOCLR1 = (1 << 16);
		}
	}
}

unsigned char uart_rx()
{
	while((U0LSR & (1<<0))==0);
	return(U0RBR);
}

void uart_init()
{
	U0LCR = 0X83;
	U0DLL = 97;
	U0DLM = 0;
	U0LCR = 0X03;
}

void uart_tx(unsigned char ch)
{
	U0THR = ch;
	while((U0LSR & (1<<6))==0);
}

void uart_str(unsigned char *str)
{
	while(*str)
	uart_tx(*str++);
}
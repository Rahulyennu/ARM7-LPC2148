#include<lpc213x.h>
#define SW		16
void lcd_init(void);
void lcd_data(unsigned char ch);
void lcd_cmd(unsigned char ch);
void lcd_str(unsigned char *str);
void lcd_delay(unsigned int i)
{
	int t;
	while(i--)
	for(t=0;t<1257;t++);
}
void Delay_Key(void)
{
	
	unsigned int i,j;
	for(i=0;i<3;i++)
		for(j=0;j<1234;j++);
}
main()
{
unsigned char M,N,Row_Data, Col_Data;
unsigned char Msg[4][4] = 	{ '7','8','9','-',
															'4','5','6','x',
															'1','2','3','-',
															'*','0','=','+' };
PINSEL0 = 0;
PINSEL1 = 0;
PINSEL2 = 0;
//IODIR1 = (1<<20)|(1<<21)|(1<<22);
IODIR0 = 0XC0FF0000;
lcd_init();
lcd_data('*');
lcd_str("PRESS KEYPAD");
while(1)
{

	Delay_Key();
	IODIR1 = (0x0F << SW);		// Configuring Rows as Input && Colum as OutPut	 (P1.16 - P1.23)
	IOPIN1 = (0xF0 << SW);		// Push Column Values to LOW so as to get ROW value

	while (((IOPIN1>>SW)&0x00F0) == 0xF0);
	
	M = IOPIN1 >> SW;

	if (M == 0xE0)
	{
		Row_Data = 0; 
	}
	else if (M == 0xD0)
	{
		Row_Data = 1; 
	}
	else if (M == 0xB0)
	{
		Row_Data = 2; 
	}
	else if (M == 0x70)
	{
		Row_Data = 3; 
	}
	else
		Row_Data = 4; 

	
//	Delay_Key();
			
	/*^^^^^^^^^^^^^^^^^^^ Scanning of Column ^^^^^^^^^^^^^^^^^^^^^^^^^*/
	IOPIN1	=	0x0F << SW;
	IODIR1	= 	(0xF0 << SW);		// Configure Column as Input and Rows as OutPut	(P1.16 - P1.23)
	
	IOPIN1	= 	(0x0F << SW);		// Push LOW to Rows to get the Column value of Key Press

	while (((IOPIN1>>SW)&0x000F) == 0x0F);

	N = (IOPIN1 >> SW);

	if (N == 0x0E)
	{
		Col_Data = 0; 
	}
	else if (N == 0x0D)
	{
		Col_Data = 1; 
	}
	else if (N == 0x0B)
	{
		Col_Data = 2; 
	}
	else if (N == 0x07)
	{
		Col_Data = 3; 
	}
	else
		Col_Data = 4; 

//	Delay_Key();
	IOPIN1	=	0xF0 << SW;
	Delay_Key(); 
	if (Row_Data < 4 && Col_Data < 4)
		{
			lcd_cmd(0xCE);
			lcd_data (Msg[Col_Data][Row_Data]);
			Delay_Key();
		}
}
}

void lcd_init()
{
	lcd_cmd(0x38);lcd_delay(10);
	lcd_cmd(0x06);lcd_delay(10);
	lcd_cmd(0x0c);lcd_delay(10);
	lcd_cmd(0x01);lcd_delay(10);
	lcd_cmd(0x80);lcd_delay(10);
}
void lcd_data(unsigned char ch)
{
	IOPIN0 &= 0XFF00FFFF;
	IOPIN0 |= (ch<<16);
	IOSET0 = (1<<30);
	IOSET0 = (1<<31);
	lcd_delay(1);
	IOCLR0 = (1<<31);
}
void lcd_cmd(unsigned char ch)
{
	IOPIN0 &= 0XFF00FFFF;
	IOPIN0 |= (ch<<16);
	IOCLR0 = (1<<30);
	IOSET0 = (1<<31);
	lcd_delay(1);
	IOCLR0 = (1<<31);
}
void lcd_str(unsigned char *str)
{
	while(*str)
	lcd_data(*str++);
}

#include<lpc214x.h>
void uart_init()
{
	U0LCR = 0X83;
	U0DLL = 97;
	U0DLM = 0;
	U0LCR = 0X03;
}
void uart_tx(unsigned char CH)
{
	U0THR = CH;
	while((U0LSR & (1<<6))==0);
}
main()
{
	PINSEL0 = 0X05;
	PINSEL2 = 0;
	IODIR1 &= ~(1<<16);
	IODIR1 &= ~(1<<17);
	uart_init();
	while(1)
	{
		if((IOPIN1 & (1<<16))==0)
		{
			uart_tx('A');
		}
		else if((IOPIN1 & (1<<17))==0)
		{
			uart_tx('B');
		}
	}
}
#include<lpc214x.h>

void delay(unsigned int i);
void lcd_cmd(unsigned char ch)
{
	IOPIN0 &= 0XFF00FFFF;
	IOPIN0 |= (ch<<16);
	IOCLR1 =(1<<20);
	IOCLR1 = (1<<21);
	IOSET1 = (1<<22);
	delay(10);
	IOCLR1 = (1<<22);
}
void lcd_data(unsigned char ch)
{
	IOPIN0 &= 0XFF00FFFF;
	IOPIN0 |= (ch<<16);
	IOSET1 =(1<<20);
	IOCLR1 = (1<<21);
	IOSET1 = (1<<22);
	delay(10);
	IOCLR1 = (1<<22);
}

void lcd_init()
{
lcd_cmd(0x38);
lcd_cmd(0x06);
lcd_cmd(0x0c);
lcd_cmd(0x01);
lcd_cmd(0x80);
}

void lcd_str(unsigned char *str)
{
	while(*str)
	{
	lcd_data(*str++);
	}
}

int main(void)
{
PINSEL1 = 0;
PINSEL2 = 0;
IODIR0 = 0X00FF0000;
IODIR1 = (1<<20)|(1<<21)|(1<<22);
lcd_init();
	lcd_cmd(0x80);
	lcd_data('a');
	lcd_cmd(0x81);
	lcd_str("hello vit");
	while(1);
}


void delay(unsigned int i)
{
int t;
while(i--)
for(t=0;t<1200;t++);
}
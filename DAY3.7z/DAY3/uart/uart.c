#include<lpc214x.h>
unsigned char ARRAY[4];
void uart_init();
void uart_tx(unsigned char ch);
void uart_str(unsigned char *str);
unsigned char uart_rx();

void DECtoASCII( unsigned int val)
{
unsigned int check0 , check1 , check2;
check0 = val;
ARRAY[0] = (check0 / 100) + 48;
check1 = val % 100;
ARRAY[1] = (check1 / 10) + 48;
check2 = val % 10;
ARRAY[2] = (check2 / 1) + 48;
ARRAY[3] = '\0' ;
}

main()
{
	unsigned char X;
	unsigned int AD01;
	PINSEL0 = 0x00000005;
	PINSEL1 = 0X15000000;
	PINSEL2 = 0;
	IODIR1 = (1<<16)|(1<<17);
	uart_init();
	VPBDIV = 0X02;
	uart_tx('a');
	uart_str("\nWAKE UP");
	
	while(1)
	{
		AD0CR = 0X00200602;
		AD0CR |= (1<<24);
		while((AD0DR1 & (1<<31))==0);
		AD01 = ((AD0DR1 >> 6) & 0X3FF);
		DECtoASCII(AD01);
		uart_str(ARRAY);
		uart_str("\n");

		X = uart_rx();
		if(X == 'A')
		{
		  IOSET1 = (1<<16);
		  IOCLR1 = (1 << 17);
		}
		else if(X == 'B')
		{
		  
		  IOSET1 = (1<<17);
		  IOCLR1 = (1 << 16);
		}
	}
}

unsigned char uart_rx()
{
	while((U0LSR & (1<<0))==0);
	return(U0RBR);
}

void uart_init()
{
	U0LCR = 0X83;
	U0DLL = 97;
	U0DLM = 0;
	U0LCR = 0X03;
}

void uart_tx(unsigned char ch)
{
	U0THR = ch;
	while((U0LSR & (1<<6))==0);
}

void uart_str(unsigned char *str)
{
	while(*str)
	uart_tx(*str++);
}